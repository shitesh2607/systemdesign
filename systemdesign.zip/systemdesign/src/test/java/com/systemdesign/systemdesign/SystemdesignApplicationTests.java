package com.systemdesign.systemdesign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemdesignApplicationTests {

	@Test
	void contextLoads() {
	}

}
